package com.data.ayuntamientoaccess.config;

public class WebClientConfig {
    
}
